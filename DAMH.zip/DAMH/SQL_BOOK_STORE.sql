﻿USE master
GO
CREATE DATABASE BOOKSTORE
GO
USE BOOKSTORE
GO
CREATE TABLE author (
  id_author bigint NOT NULL IDENTITY,
  author_name nvarchar(50) DEFAULT NULL,
  CONSTRAINT PK_Author PRIMARY KEY (id_author)
)
GO
CREATE TABLE category (
  category_id bigint NOT NULL IDENTITY,
  category_name nvarchar(255) DEFAULT NULL,
  CONSTRAINT PK_Category PRIMARY KEY (category_id)
)

GO
CREATE TABLE company (
  id_company bigint NOT NULL IDENTITY,
  company_name nvarchar(255) DEFAULT NULL,
  CONSTRAINT PK_Company PRIMARY KEY (id_company)
)

GO
CREATE TABLE book (
  id_book bigint NOT NULL IDENTITY,
  book_name nvarchar(45),
  describe_book nvarchar(2000) DEFAULT NULL,
  picture nvarchar(255) DEFAULT NULL,
  price bigint DEFAULT NULL,
  publish_day date DEFAULT NULL,
  total_quantity int DEFAULT NULL,
  id_author bigint DEFAULT NULL,
  category_id bigint DEFAULT NULL,
  id_company bigint DEFAULT NULL,
  CONSTRAINT PK_Book PRIMARY KEY (id_book),
  CONSTRAINT FK_Author_Book FOREIGN KEY (id_author) REFERENCES author (id_author),
  CONSTRAINT FK_Category_Book FOREIGN KEY (category_id) REFERENCES category (category_id),
  CONSTRAINT FK_Company_Book FOREIGN KEY (id_company) REFERENCES company (id_company),
  )

  GO
  CREATE TABLE users (
  user_id int NOT NULL IDENTITY,
  age int NOT NULL,
  email varchar(255) DEFAULT NULL,
  gender bit NOT NULL,
  password varchar(250) DEFAULT NULL,
  phone varchar(10) DEFAULT NULL,
  username varchar(255) DEFAULT NULL,
  address nvarchar(255) DEFAULT NULL,
  role int DEFAULT 0,
  CONSTRAINT PK_Users PRIMARY KEY (user_id),
  )

 GO
 INSERT INTO users VALUES (22, 'ducngoc@gmail.com', 1, '123', '0378544081', 'ducngoc', N'Nghệ An', 1),
 (25, 'admin@gmail.com', 1, '123456', '0378544080', 'admin',N'Hà Nội', 1),
 (20, 'minh@gmail.com', 1, '1', '0378544080', 'minh', N'Khánh Hòa', 0),
 (19, 'hai@gmail.com', 1, '1', '0384271181', 'hai', N'Vĩnh Phúc', 0),
 (12, 'phuc@gmail.com', 1, '1', '0862148114', 'phuc', N'Nghệ An', 0),
 (17, 'tai@gmail.com', 1, '1', '0346450639', 'tai', N'TP HCM', 0),
 (19, 'quan@gmail.com', 1, '1', '0346251276', 'quan',N'Hà Nội', 0),
 (12, 'phat@gmail.com', 1, '1', '0338957688', 'phat', N'Nghệ An', 0),
 (16, 'luong@gmail.com', 1, '1', '0378544080', 'luong',N'Nghệ An', 0),
 (18, 'tam@gmail.com', 1, '1', '0868807447', 'tam',N'Nghệ An', 0),
 (16, 'hung@gmail.com', 1, '1', '0369200372', 'hung',N'Nghệ An', 0),
 (12, 'nam@gmail.com', 1, '1', '0369200372', 'nam',N'Nghệ An', 0),
 (19, 'phong@gmail.com', 1, '1', '0862444595', 'phong',N'Nghệ An', 0),
 (19, 'huong@gmail.com', 0, '1', '0332101812', 'huong',N'Nghệ An', 0),
 (19, 'huyen@gmail.com', 0, '1', '0346693468', 'huyen',N'Nghệ An', 0)

  GO
  INSERT INTO category VALUES (N'Sách giáo khoa'),
  (N'Sách kỹ năng'),
  (N'Tiểu thuyết'),
  (N'Sách văn hóa lịch sử'),
  (N'Sách tôn giáo');
  GO
 INSERT INTO author VALUES (N'Tố Hữu'),
 (N'Chế Lan Viên'),
 (N'Nguyễn Duy'),
 (N'Thế Lữ'),
 (N'Lý Bạch'),
 (N'Nguyễn Du'),
 (N'Đỗ Bích Thúy'),
 (N'Napoleon Hill'),
 (N'Tôn Nghộ Không'),
 (N'Nguyễn Nhật Ánh'),
 (N'Trạng Nguyên');

 GO
 INSERT INTO company VALUES (N'Tôn giáo'),
(N'Giáo dục'),
(N'Ngôi Sao'),
(N'Khoa học và kỹ thuật'),
(N'Tài chính'),
(N'Nông nghiệp'),
(N'Tuổi trẻ'),
(N'Thể dục thể thao'),
(N'Đại học quốc gia Hà Nội'),
(N'Thanh niên'),
(N'Kim Đồng');

  GO
  INSERT INTO book VALUES (N'Tự Nhiên Và Xã Hội 3',N'Trong kho tàng văn học dân gian Việt Nam, sách Truyện Trạng Quỳnh Và Xiển Bột thuộc loại truyện cười đặc sắc nhất. Đặc sắc bởi vì các câu chuyện không chỉ mang lại tiếng cười mà còn có tính chiến đấu cao; phê phán, giễu cợt, chống đối, lật nhào từ vương quyền đến thần quyền, từ vua chúa đến quan lại, từ bọn thực dân xâm lược đến bọn phong kiến bán nước. Sau tiếng cười hả hê, sách hiện lên là những kẻ mất nhân cách, dốt nát, xảo quyệt, gian tham, tàn ác, vào luồn ra cúi; những thói hư tật xấu của con người... Bên cạnh tiếng cười đả kích còn có tiếng cười dí dỏm nhẹ nhàng khi tự trào, đùa cợt bạn bè, người thân.','tnxh3.jpg',120000.00,'1998-10-21',190,5,3,3),
  (N'Đạo Đức 2',N'Đây là cuồn sách giúp bạn thu phục lòng người','dao-duc2.jpg',200000,'1995-10-01',150,7,2,3),
  (N'Tiếng Anh 9',N'Đây là cuốn sách giúp bạn chinh phục mọi thứ trong cuộc đời','anh9.jpg',80000,'1998-01-01',204,9,2,3),
  (N'Âm Nhạc 3',N'Làm giàu không khó ','nhac3.jpg',110000,'2005-05-12',180,10,2,10),
  (N'Nghĩ giàu làm giàu',N'Nghĩ là làm, không nói nhiều','sach-yeu-thich.jpg',95000,'2022-01-01',63,8,2,7),
  (N'Toán 3',N'Tuổi trẻ phải đọc một lần','toan3.jpg',78000,'2015-01-01',71,11,2,7),
  (N'Tiếng anh 2',N'Tiếng anh giao tiếp phiên bản giới hạn','tieng-anh2.jpg',25000,'2022-03-03',100,11,2,7),
  (N'Gió lạnh đầu mùa',N'Gió đầu mùa lạnh lắm','gio-lanh-dau-mua.jpg',72000,'2022-05-11',15,11,2,7),
  (N'Lạc mất tìm lại',N'Có không giữ mất đừng tìm','lac-mat-tim-lai.jpg',75000,'2022-02-11',15,11,2,7);

  GO

  CREATE TABLE review (
  id_book bigint NOT NULL,
  user_id int NOT NULL,
  comments nvarchar(200) DEFAULT NULL,
  star float NOT NULL,
  time date DEFAULT NULL,
  CONSTRAINT PK_Review PRIMARY KEY (id_book, user_id),
  CONSTRAINT FK_Review_IDBook FOREIGN KEY (id_book) REFERENCES book (id_book),
  CONSTRAINT FK_Review_Users FOREIGN KEY (user_id) REFERENCES users (user_id)
  )
  GO


  INSERT INTO review VALUES (1,3,N'quá hay',5,'2022-04-11'),
  (6,5,N'Tạm được',1,'2022-04-03'),(4,6,N'Sách quá xuất sắc',3,'2022-03-13'),
  (7,8,N'Vì nhiều người đọc đọc nên mới mua đó nhé',3,'2022-04-02'),
  (1,11,N'Cũng ổn',4,'2022-02-16'),
  (1,4,N'Ship thì rất đúng giờ, nhưng sai ngày',4,'2022-04-16'),
  (6,10,N'Sản phẩm rât tốt',5,'2022-01-21'),
  (4,12,N'Shop dẹp đi cho rồi',3,'2022-04-22'),
  (2,5,N'Đọc không sót một chữ',5,'2022-01-21'),
  (2,4,N'Sách thiết kế quá đẹp, nên mua',5,'2022-04-22');

GO
CREATE TABLE orders (
  order_id int NOT NULL IDENTITY,
  customer_name nvarchar(255) DEFAULT NULL,
  order_day date DEFAULT NULL,
  order_status int DEFAULT NULL,
  customer_phone varchar(10) DEFAULT NULL,
  total_price bigint DEFAULT NULL,
  address nvarchar(255) DEFAULT NULL,
  user_id int DEFAULT NULL,
  CONSTRAINT PK_Orders PRIMARY KEY (order_id),
  CONSTRAINT FK_Order_User FOREIGN KEY (user_id) REFERENCES users (user_id)
)
GO
--- 1: chờ xác nhận 2: Đã xác nhận (Đã giao) 3: Yêu cầu hủy 4: Đã hủy
INSERT INTO orders VALUES (N'tai','2022-03-25',2,'0346450639',95000,N'25/3 Lạc Long Quân, Q.10,TP HCM',6),
(N'ducngoc','2022-04-24',2,'0378544081',95000,N'125 Trần Hưng Đạo, Q.1, TP HCM',1),
(N'Đức Ngọc','2022-05-26',1,'0987654321',770000,N'12/21 Võ Văn Ngân Thủ Đức, TP HCM',NULL),
(N'Quân','2022-02-26',1,'0327890098',173000,N'22/11 Lý Thường Kiệt,TP Mỹ Tho',NULL),
(N'Phong Blue','2022-01-26',3,'0862444595',475000,N'221 Hùng Vương,Q.5, TP HCM',13),
(N'Nam Thích Thảo','2022-04-27',4,'0369200372',915000,N'215 Lý Thường Kiệt,TP Biên Hòa',12),
(N'phat','2022-01-20',2,'0338957688',915000,N'22/5 Điện Biên Phủ, Q.Bình Thạnh, TP HCM',8),
(N'tai','2022-02-21',2,'0346450639',95000,N'25/3 Lạc Long Quân, Q.10,TP HCM',6),
(N'tai','2021-10-22',2,'0346450639',95000,N'25/3 Lạc Long Quân, Q.10,TP HCM',6),
(N'tai','2021-10-27',2,'0346450639',95000,N'123 Phường Phúc Xá, Quận Ba Đình, Thành phố Hà Nội',6),
(N'tai','2021-10-22',1,'0346450639',95000,N'123 Thị trấn Thứa, Huyện Lương Tài, Tỉnh Bắc Ninh',6)

GO
CREATE TABLE order_detail (
  id bigint NOT NULL IDENTITY,
  price int DEFAULT NULL,
  quantity int NOT NULL,
  id_book bigint DEFAULT NULL,
  order_id int DEFAULT NULL,
  PRIMARY KEY (id),
  CONSTRAINT FK_Detail_Book FOREIGN KEY (id_book) REFERENCES book (id_book),
  CONSTRAINT FK_Detail_Order FOREIGN KEY (order_id) REFERENCES orders (order_id)
  )

  GO
INSERT INTO order_detail VALUES (95000,1,5,1),
(95000,1,5,2),(78000,5,7,3),(95000,4,5,3),
(95000,1,5,4),(78000,1,7,4),(95000,5,5,5),
(80000,3,3,6),(78000,5,7,6),(95000,3,5,6),
(78000,5,7,7),(80000,3,3,7),(95000,3,5,7),
(95000,1,5,9),(95000,1,5,10),
(95000,1,5,11)

GO
CREATE TABLE items (
item_id bigint NOT NULL IDENTITY,
quantity_books int DEFAULT NULL,
id_book bigint DEFAULT NULL,
user_id int DEFAULT NULL,
CONSTRAINT PK PRIMARY KEY (item_id),
CONSTRAINT FK_Items_Book FOREIGN KEY (id_book) REFERENCES book(id_book),
CONSTRAINT FK_Items_Users FOREIGN KEY (user_id) REFERENCES users(user_id),
)

GO
INSERT INTO items VALUES (5, 1, 2), (10, 2, 2)
GO






-- DELETE
--DELETE order_detail
--DELETE orders
--DELETE review
--DELETE district
--DELETE province
--DELETE items
--DELETE book
--DELETE author
--DELETE category
--DELETE company
--DELETE users


--INSERT INTO users VALUES (25, 'admin@gmail.com', 1, '1', '0378544080', 'admin', 1)
--INSERT INTO users VALUES (20, 'ngoc@gmail.com', 1, '1', '0378544080', 'ngoc', 0)


 -- SELECT BOOK.id_book, book.book_name, book.picture, review.star, COUNT (star) AS ST FROM BOOK INNER JOIN review ON BOOK.id_book = review.id_book
 -- GROUP BY BOOK.id_book, review.star, book.picture, book.book_name
 -- ORDER BY id_book ASC, review.star DESC


 -- SELECT BOOK.id_book, book.book_name, book.picture, review.star AS ST FROM BOOK INNER JOIN review ON BOOK.id_book = review.id_book


 -- select star,count(*) from review where id_book=2
 -- group by star
 -- order by star desc

 -- select star,count(*) from review where id_book=3
 -- group by star
 -- order by star desc
--  select AVG (star) from review where id_book=1

